/**
@author Cedric nguendap
@description Cette classe represente un demandeur de service 
@created 13/10/2020
*/

import { Customer } from "./customer";

export class ServiceRequester extends Customer
{}