import { Service } from "../../../karryngo_core/decorator/dependecy_injector.decorator";

@Service()
export class GOAuth2Service
{
    
}