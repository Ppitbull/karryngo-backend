import { Service } from "../../../karryngo_core/decorator";

@Service()
export class GOAuth2Service
{
    
}