export enum AccountType
{
    SUPER_ADMIN_ACCOUNT="super_admin",
    CUSTOMER_ACCOUNT="customer",
    MANAGER_ACCOUNT="admin_manager",
    UNKNOW_ACCOUNT="unknow"
}